/2. Crie um programa que classifica a idade de uma pessoa em categorias (criança, adolescente, adulto, idoso) com base no valor fornecido, utilizando uma estrutura de controle if-else./

var idade = 27;

if(idade > 3 && idade < 10){ console.log("fase criança");

}else if(idade >= 12 && idade <=18){ console.log("fase adolescente");

}else if(idade >18 && idade<=40){ console.log("fase adulta");

}else if(idade > 60 && idade<=100){ console.log("fase idosa");

}else{

console.log("Idade além da permitida, nota-se > 100");

}