/* 8. Escreva um algoritmo para ler 2 valores (considere que não serão lidos valores iguais)
e escreve-los em ordem crescente.*/

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Digite o primeiro valor: ", (valor1) => {
    rl.question("Digite o segundo valor: ", (valor2) => {
        valor1 = parseFloat(valor1);
        valor2 = parseFloat(valor2);

        if (valor1 > valor2) {
            console.log(Valores em ordem crescente: ${valor2}, ${valor1});
        } else {
            console.log(Valores em ordem crescente: ${valor1}, ${valor2});
        }

        rl.close();
    });
});