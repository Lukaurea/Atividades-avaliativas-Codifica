/* 9.Implemente um programa que exibe uma contagem regressiva de 10 até 1 no console
utilizando um loop for */

for (let i = 10; i >= 1; i--) {
    console.log(i);
}