/*4. Crie um menu interativo no console que oferece ao usuário a escolha de três opções. Utilize switch-case para implementar a lógica de cada opção selecionada. */
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log("Escolha uma das opções abaixo:");
console.log("1. Dizer Olá");
console.log("2. Mostrar a data atual");
console.log("3. Sair");

rl.question("Digite o número da opção desejada: ", (value) => {
    value = parseInt(value);

    switch (value) {
        case 1:
            console.log("Olá! Como você está?");
            break;
        case 2:
            const dataAtual = new Date();
            console.log(A data e hora atuais são: ${dataAtual});
            break;
        case 3:
            console.log("Saindo... Até a próxima!");
            break;
        default:
            console.log("Opção inválida! Por favor, escolha uma das opções.");
    }

    rl.close();
});