/*7.As maçãs custam R$ 0,30 se forem compradas menos do que uma dúzia, e R$ 0,25 se
forem compradas pelo menos doze. Escreva um algoritmo que leia o número de maçãs
compradas, calcule e escreva o valor total da compra.*/

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Quantas maçãs você deseja comprar? ", (quantidade) => {
    quantidade = parseInt(quantidade);

    let precoPorUnidade;

    if (quantidade < 12) {
        precoPorUnidade = 0.30;
    } else {
        precoPorUnidade = 0.25;
    }

    const valorTotal = quantidade * precoPorUnidade;
    console.log(O valor total da compra é: R$ ${valorTotal.toFixed(2)});

    rl.close();
});