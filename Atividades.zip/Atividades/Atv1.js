/1. Escreva um programa que recebe um número inteiro e verifica se ele é par ou impar utilizando uma estrutura de controle if./

const readline = require('readline');

const rl = readline.createInterface({

input: process.stdin,

output: process.stdout

})

rl.question("digite o dado para análise: ", (value) => {

var value = parseInt(value)

if (value % 2 === 0) {

console.log('Este é um número par: ${value}');

}else{

console.log('Este é um número impar: ${value}');

}

rl.close();

})