/* 13. Fazer um algoritmo para receber números decimais até que o usuário digite 0 e fazer
a média aritmética desses números.*/

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let soma = 0;
let contador = 0;

function solicitarNumero() {
    rl.question("Digite um número decimal (ou 0 para sair): ", (numero) => {
        numero = parseFloat(numero);

        if (numero !== 0) {
            soma += numero;
            contador++;
            solicitarNumero();
        } else {
            const media = contador > 0 ? soma / contador : 0;
            console.log(A média aritmética é: ${media.toFixed(2)});
            rl.close();
        }
    });
}

solicitarNumero();