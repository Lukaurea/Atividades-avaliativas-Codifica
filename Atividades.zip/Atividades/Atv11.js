/* 11. Escreva um programa que solicita ao usuário 5 números e calcula a soma total
utilizando um loop for.*/

const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let soma = 0;
let contador = 0;

function solicitarNumero() {
    rl.question(`Digite o número ${contador + 1}: `, (numero) => {
        soma += parseFloat(numero);
        contador++;

        if (contador < 5) {
            solicitarNumero();
        } else {
            console.log(A soma total dos 5 números é: ${soma});
            rl.close();
        }
    });
}

solicitarNumero();