[22:18, 31/08/2024] Lucas: /* 15. Escreva um programa que gera e imprime os primeiros 10 números da sequência de
Fibonacci utilizando um loop for.*/

let a = 0, b = 1;

console.log(a);  // Primeiro número da sequência
console.log(b);  // Segundo número da sequência

for (let i = 2; i < 10; i++) {
    let proximo = a + b;
    console.log(proximo);
    a = b;
    b = proximo;
}
